package com.redoni.mobile

import android.app.Activity
import android.os.Bundle
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.RectF
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

private val BG = Color.rgb(8, 8, 10)
private val PANEL = Color.rgb(20, 20, 24)
private val RED = Color.rgb(235, 20, 38)
private val WHITE = Color.rgb(242, 242, 245)
private val MUTED = Color.rgb(160, 160, 170)

class MainActivity : Activity() {
    private lateinit var content: LinearLayout
    private lateinit var nav: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        window.decorView.systemUiVisibility = 0
        buildShell()
        showHome()
    }

    private fun buildShell() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(BG)
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), dp(12), dp(18), dp(8))
        }
        header.addView(TextView(this).apply {
            text = "RED ONI"
            textSize = 23f
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
            setTextColor(RED)
        }, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(TextView(this).apply {
            text = "MOBILE // 01"
            textSize = 10f
            letterSpacing = .12f
            setTextColor(MUTED)
        })
        root.addView(header)

        val scroll = ScrollView(this).apply { fillViewport = true }
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(8), dp(16), dp(18))
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.rgb(15, 15, 18))
            setPadding(dp(4), dp(6), dp(4), dp(6))
        }
        listOf("ГЛАВНАЯ", "КОДЕКС", "РАНГИ", "СИМВОЛЫ").forEach { label ->
            val b = Button(this).apply {
                text = label
                textSize = 9f
                isAllCaps = false
                setTextColor(WHITE)
                setBackgroundColor(Color.TRANSPARENT)
                setOnClickListener {
                    when (label) {
                        "ГЛАВНАЯ" -> showHome()
                        "КОДЕКС" -> showCodex()
                        "РАНГИ" -> showRanks()
                        "СИМВОЛЫ" -> showSymbols()
                    }
                }
            }
            nav.addView(b, LinearLayout.LayoutParams(0, dp(48), 1f))
        }
        root.addView(nav)
        setContentView(root)
    }

    private fun showHome() {
        content.removeAllViews()
        content.addView(OniMark(this), LinearLayout.LayoutParams(-1, dp(190)))
        title("SHADOWS OBSERVE.")
        title("TRUTH REMAINS.")
        text("ЦИФРОВОЙ ЦЕНТР RED ONI", RED, 12f, true)
        text("Технологии • знания • наблюдение • развитие", MUTED, 13f)
        space(12)
        card("ПРОТОКОЛ ОРГАНИЗАЦИИ", "RED ONI объединяет людей, которым интересны технологии, исследования и постоянное обучение.")
        card("ПРИНЦИП", "Наблюдай. Анализируй. Проверяй факты. Действуй ответственно.")
        actionButton("ОТКРЫТЬ КОДЕКС") { showCodex() }
        text("BUILD 1.0  //  OFFLINE READY", MUTED, 10f)
    }

    private fun showCodex() {
        content.removeAllViews()
        heading("КОДЕКС RED ONI", "Восемь принципов организации")
        val rules = listOf(
            "01" to "Знание — наше оружие.",
            "02" to "Информация — наша сила.",
            "03" to "Анонимность — наша защита.",
            "04" to "Дисциплина — наша основа.",
            "05" to "Не причинять вред невиновным.",
            "06" to "Использовать знания во благо.",
            "07" to "Постоянно учиться и проверять источники.",
            "08" to "Не сдаваться перед трудностями."
        )
        rules.forEach { (n, rule) -> card(n, rule) }
        actionButton("НА ГЛАВНУЮ") { showHome() }
    }

    private fun showRanks() {
        content.removeAllViews()
        heading("РАНГИ", "Роли для учебного сообщества")
        listOf(
            Triple("01 // РЕКРУТ", "Изучает основы и правила.", "◇"),
            Triple("02 // НАБЛЮДАТЕЛЬ", "Собирает информацию из открытых источников.", "◉"),
            Triple("03 // АНАЛИТИК", "Проверяет данные и формирует выводы.", "△"),
            Triple("04 // ОПЕРАТОР", "Применяет навыки в разрешённых проектах.", "⌘"),
            Triple("05 // СТРАТЕГ", "Планирует задачи и помогает команде.", "✳"),
            Triple("06 // ЛИДЕР", "Поддерживает качество, безопасность и развитие.", "鬼")
        ).forEach { (rank, desc, icon) -> card("$icon   $rank", desc) }
        text("Ранги символические: они обозначают вклад и обучение, а не власть над людьми.", MUTED, 12f)
    }

    private fun showSymbols() {
        content.removeAllViews()
        heading("СИМВОЛИКА", "Визуальный язык RED ONI")
        content.addView(OniMark(this), LinearLayout.LayoutParams(-1, dp(160)))
        card("МАСКА ОНИ", "Главный знак: решительность, самоконтроль и готовность смотреть на факты.")
        card("КРАСНЫЙ", "Энергия, внимание и действие.")
        card("ЧЁРНЫЙ / ГРАФИТ", "Сдержанность, неизвестность и технологичная среда.")
        card("БЕЛЫЙ", "Ясность, проверка и баланс.")
        card("ТОРИИ", "Порог между неизвестным и познанным. Декоративный мотив, не религиозное требование.")
        actionButton("СКОПИРОВАТЬ ДЕВИЗ") {
            val clipboard = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
            clipboard.setPrimaryClip(android.content.ClipData.newPlainText("RED ONI motto", "SHADOWS OBSERVE. TRUTH REMAINS."))
            Toast.makeText(this, "Девиз скопирован", Toast.LENGTH_SHORT).show()
        }
    }

    private fun heading(main: String, sub: String) {
        text(main, RED, 22f, true)
        text(sub, MUTED, 13f)
        space(12)
    }

    private fun title(s: String) = text(s, WHITE, 21f, true)
    private fun text(s: String, color: Int = WHITE, size: Float = 14f, bold: Boolean = false) {
        content.addView(TextView(this).apply {
            text = s
            textSize = size
            setTextColor(color)
            if (bold) typeface = Typeface.create("sans-serif", Typeface.BOLD)
            setPadding(dp(2), dp(4), dp(2), dp(4))
        })
    }

    private fun card(head: String, body: String) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(PANEL)
            setPadding(dp(14), dp(10), dp(14), dp(12))
        }
        box.addView(TextView(this).apply {
            text = head
            textSize = 13f
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            setTextColor(RED)
        })
        box.addView(TextView(this).apply {
            text = body
            textSize = 14f
            setTextColor(WHITE)
            setPadding(0, dp(5), 0, 0)
        })
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.bottomMargin = dp(10)
        content.addView(box, lp)
    }

    private fun actionButton(label: String, action: () -> Unit) {
        val b = Button(this).apply {
            text = label
            textSize = 12f
            setTextColor(WHITE)
            setBackgroundColor(Color.rgb(130, 8, 22))
            setOnClickListener { action() }
        }
        val lp = LinearLayout.LayoutParams(-1, dp(50))
        lp.topMargin = dp(6)
        lp.bottomMargin = dp(12)
        content.addView(b, lp)
    }

    private fun space(px: Int) {
        content.addView(View(this), LinearLayout.LayoutParams(1, dp(px)))
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}

private class OniMark(context: android.content.Context) : View(context) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        canvas.drawColor(BG)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 2.5f
        p.color = RED
        canvas.drawCircle(w / 2, h / 2, minOf(w, h) * .34f, p)
        canvas.drawCircle(w / 2, h / 2, minOf(w, h) * .42f, p.apply { alpha = 110; strokeWidth = 1f })
        p.alpha = 255
        p.style = Paint.Style.FILL
        val cx = w / 2
        val cy = h / 2
        val hornL = Path().apply {
            moveTo(cx - 30, cy - 18); lineTo(cx - 60, cy - 62); lineTo(cx - 52, cy - 8); close()
        }
        val hornR = Path().apply {
            moveTo(cx + 30, cy - 18); lineTo(cx + 60, cy - 62); lineTo(cx + 52, cy - 8); close()
        }
        p.color = RED
        canvas.drawPath(hornL, p)
        canvas.drawPath(hornR, p)
        val face = Path().apply {
            moveTo(cx - 43, cy - 22)
            lineTo(cx - 32, cy + 25)
            lineTo(cx, cy + 52)
            lineTo(cx + 32, cy + 25)
            lineTo(cx + 43, cy - 22)
            lineTo(cx, cy - 40)
            close()
        }
        p.color = WHITE
        canvas.drawPath(face, p)
        p.color = Color.rgb(30, 30, 34)
        val left = Path().apply { moveTo(cx - 36, cy - 12); lineTo(cx - 8, cy - 4); lineTo(cx - 27, cy + 8); close() }
        val right = Path().apply { moveTo(cx + 36, cy - 12); lineTo(cx + 8, cy - 4); lineTo(cx + 27, cy + 8); close() }
        canvas.drawPath(left, p)
        canvas.drawPath(right, p)
        p.color = RED
        canvas.drawCircle(cx - 24, cy - 4, 4f, p)
        canvas.drawCircle(cx + 24, cy - 4, 4f, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 3f
        canvas.drawLine(cx - 17, cy + 28, cx + 17, cy + 28, p)
        p.style = Paint.Style.FILL
        p.color = WHITE
        p.textAlign = Paint.Align.CENTER
        p.typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
        p.textSize = 17f
        canvas.drawText("RED ONI", cx, h - dp(7), p)
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density)
}
